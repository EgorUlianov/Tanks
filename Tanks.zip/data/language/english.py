eng = {'Play': 'Play',
       'Control': 'Control',
       'Language': 'Languege',
       'Exit': 'Exit',
       'Upward': 'Up',
       'Left': 'Left',
       'Right': 'Right',
       'Backward': 'Backward',
       'Shot': 'Shot'
       }
