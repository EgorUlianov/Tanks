rus = {'Play': 'Играть',
       'Control': 'Управление',
       'Language': 'Язык',
       'Exit': 'Выход',
       'Upward': 'Вверх',
       'Left': 'Влево',
       'Right': 'Вправо',
       'Backward': 'Назад',
       'Shot': 'Выстрел'
       }
